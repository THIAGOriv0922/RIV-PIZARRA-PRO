"""Apply RIV changes to an existing clean OpenBoard v1.7.7 checkout. GPL-3.0-or-later."""
from pathlib import Path
import argparse, shutil, xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent

def replace_once(s, old, new, path):
    if s.count(old)!=1: raise ValueError(f'Ancla no única o ausente: {path}: {old[:75]}')
    return s.replace(old,new,1)

def apply(root):
    root=Path(root).resolve()
    app=root/'src/core/UBApplication.cpp'; ui=root/'resources/forms/mainWindow.ui'; pro=root/'OpenBoard.pro'
    for p in (app,ui,pro):
        if not p.is_file(): raise FileNotFoundError(p)
    a=app.read_text(encoding='utf-8'); u=ui.read_text(encoding='utf-8'); p=pro.read_text(encoding='utf-8')
    if 'RIVResourceDock.h' in a: raise ValueError('El parche ya está aplicado.')
    a=replace_once(a,'#include "core/memcheck.h"','#include "RIVResourceDock.h"\n#include "core/memcheck.h"',app)
    a=replace_once(a,'    if (css.length() > 0)\n        setStyleSheet(css);','    QFile rivCss(":/riv/riv.qss");\n    if (rivCss.open(QIODevice::ReadOnly))\n        css += "\\n" + QString::fromUtf8(rivCss.readAll());\n    if (!css.isEmpty())\n        setStyleSheet(css);\n    setApplicationDisplayName(QStringLiteral("RIV PIZARRA PRO"));\n    setWindowIcon(QIcon(":/riv/icon.svg"));',app)
    a=replace_once(a,'    boardController->setupLayout();','    boardController->setupLayout();\n    mainWindow->setWindowTitle(QStringLiteral("RIV PIZARRA PRO"));\n    mainWindow->setWindowIcon(QIcon(":/riv/icon.svg"));\n    mainWindow->actionMenu->setText(QStringLiteral("RIV"));\n    mainWindow->actionMenu->setToolTip(QStringLiteral("RIV PIZARRA PRO"));\n    mainWindow->actionMenu->setIcon(QIcon(":/riv/icon.svg"));\n    RIV::installResourceDock(mainWindow, boardController);',app)
    u=replace_once(u,'<property name="windowTitle">\n   <string>OpenBoard</string>','<property name="windowTitle">\n   <string>RIV PIZARRA PRO</string>',ui)
    rc=root/'resources/win/OpenBoard.rc'
    rc_text=rc.read_text(encoding='utf-8-sig') if rc.is_file() else None
    if rc_text is not None:
        for key in ('FileDescription','ProductName'):
            import re
            rc_text,n=re.subn(r'(VALUE \"'+key+r'\",\s+\")OpenBoard',r'\g<1>RIV PIZARRA PRO',rc_text)
            if n!=1: raise ValueError('No se encontro metadato '+key)
    # Keep original target for upstream deployment scripts; only visible branding changes.
    p += '\n# RIV PIZARRA PRO resources\nHEADERS += src/core/RIVResourceDock.h\nRESOURCES += resources/riv/riv.qrc\n'
    target=root/'resources/riv'; target.mkdir(parents=True,exist_ok=True)
    shutil.copy2(HERE/'RIVResourceDock.h',root/'src/core/RIVResourceDock.h')
    for name in ('riv.qss','icon.svg'): shutil.copy2(HERE/name,target/name)
    shutil.copytree(HERE/'recursos', target/'catalog',dirs_exist_ok=True)
    rcc=ET.Element('RCC'); q=ET.SubElement(rcc,'qresource',prefix='/riv')
    for file in sorted(target.rglob('*')):
        if file.is_file() and file.suffix in ('.png','.svg','.qss'):
            ET.SubElement(q,'file').text=file.relative_to(target).as_posix()
    ET.indent(rcc); ET.ElementTree(rcc).write(target/'riv.qrc',encoding='utf-8',xml_declaration=True)
    for f,s in [(app,a),(ui,u),(pro,p)]: f.write_text(s,encoding='utf-8')
    if rc_text is not None:
        rc.write_text(rc_text,encoding='utf-8')
        shutil.copy2(HERE/'OpenBoard.ico',rc.parent/'OpenBoard.ico')
    print('Parche RIV aplicado:',root)
    print('Recursos:',len(list((target/'catalog').rglob('*.png'))))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('openboard',help='Ruta al código fuente OpenBoard v1.7.7'); args=parser.parse_args();apply(args.openboard)
