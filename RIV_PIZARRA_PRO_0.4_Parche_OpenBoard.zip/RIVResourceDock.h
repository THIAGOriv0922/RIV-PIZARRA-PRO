// RIV Pizarra PRO extension for OpenBoard 1.7.7. GPL-3.0-or-later.
#pragma once
#include <QAction>
#include <QDockWidget>
#include <QListWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QDir>
#include <QDrag>
#include <QMimeData>
#include <QImage>
#include <QFile>
#include <QIcon>
#include <QToolBar>
#include <QMainWindow>
#include <QGraphicsView>
#include "board/UBBoardController.h"
#include "board/UBBoardView.h"
#include "gui/UBMainWindow.h"

namespace RIV {
inline QMimeData* resourceMime(const QString& path) {
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) return nullptr;
    const QByteArray bytes = file.readAll();
    const QImage image = QImage::fromData(bytes, "PNG");
    if (image.isNull()) return nullptr;
    auto* mime = new QMimeData;
    mime->setImageData(image);
    mime->setData("image/png", bytes);
    return mime;
}
class ResourceList final : public QListWidget {
public:
    explicit ResourceList(QWidget* parent=nullptr) : QListWidget(parent) {
        setViewMode(QListView::IconMode);
        setResizeMode(QListView::Adjust);
        setMovement(QListView::Static);
        setSelectionMode(QAbstractItemView::SingleSelection);
        setDragEnabled(true);
        setDragDropMode(QAbstractItemView::DragOnly);
        setDefaultDropAction(Qt::CopyAction);
        setIconSize(QSize(68, 58));
        setGridSize(QSize(104, 104));
        setWordWrap(true);
        setSpacing(3);
    }
protected:
    void startDrag(Qt::DropActions) override {
        if (!currentItem()) return;
        auto* mime = resourceMime(currentItem()->data(Qt::UserRole).toString());
        if (!mime) return;
        auto* drag = new QDrag(this);
        drag->setMimeData(mime);
        drag->setPixmap(currentItem()->icon().pixmap(68,58));
        drag->exec(Qt::CopyAction);
    }
};
inline void installResourceDock(UBMainWindow* window, UBBoardController* controller) {
    auto* dock = new QDockWidget(QStringLiteral("Recursos RIV"), window);
    dock->setObjectName(QStringLiteral("rivResourceDock"));
    dock->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);
    dock->setFeatures(QDockWidget::DockWidgetClosable | QDockWidget::DockWidgetMovable);
    auto* panel = new QWidget(dock);
    auto* layout = new QVBoxLayout(panel);
    layout->setContentsMargins(9,9,9,9);
    layout->setSpacing(8);
    auto* category = new QComboBox(panel);
    auto* search = new QLineEdit(panel);
    search->setPlaceholderText(QStringLiteral("Buscar recurso…"));
    search->setClearButtonEnabled(true);
    auto* list = new ResourceList(panel);
    list->setObjectName(QStringLiteral("rivResources"));
    layout->addWidget(category);
    layout->addWidget(search);
    layout->addWidget(list,1);
    const QDir root(QStringLiteral(":/riv/catalog"));
    category->addItem(QStringLiteral("Todos los recursos"), QString());
    for (const auto& folder : root.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name))
        category->addItem(folder.mid(3), folder);
    const auto reload = [category, search, list, root]() {
        list->clear();
        const QString filter = search->text().trimmed();
        const QString selected = category->currentData().toString();
        for (const auto& folder : root.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {
            if (!selected.isEmpty() && folder != selected) continue;
            const QDir dir(root.filePath(folder));
            for (const auto& file : dir.entryList(QStringList{QStringLiteral("*.png")}, QDir::Files, QDir::Name)) {
                const QString name = file.chopped(4);
                if (!name.contains(filter, Qt::CaseInsensitive)) continue;
                const QString path = dir.filePath(file);
                auto* item = new QListWidgetItem(QIcon(path), name, list);
                item->setData(Qt::UserRole,path);
                item->setToolTip(name);
            }
        }
    };
    QObject::connect(category, QOverload<int>::of(&QComboBox::currentIndexChanged), panel, reload);
    QObject::connect(search, &QLineEdit::textChanged, panel, reload);
    QObject::connect(list, &QListWidget::itemDoubleClicked, panel, [controller](QListWidgetItem* item) {
        if (!controller || !controller->controlView()) return;
        auto* mime = resourceMime(item->data(Qt::UserRole).toString());
        if (!mime) return;
        auto* view = controller->controlView();
        controller->processMimeData(mime, view->mapToScene(view->viewport()->rect().center()));
        delete mime;
    });
    reload();
    dock->setWidget(panel);
    dock->setMinimumWidth(224);
    window->addDockWidget(Qt::RightDockWidgetArea,dock);
    dock->hide();
    auto* toggle = dock->toggleViewAction();
    toggle->setText(QStringLiteral("Recursos"));
    toggle->setIcon(QIcon(QStringLiteral(":/riv/icon.svg")));
    toggle->setToolTip(QStringLiteral("Abrir recursos matemáticos y geométricos"));
    window->boardToolBar->insertAction(window->actionMenu,toggle);
    QObject::connect(window->actionWeb,&QAction::triggered,dock,&QWidget::hide);
    QObject::connect(window->actionDocument,&QAction::triggered,dock,&QWidget::hide);
    QObject::connect(window->actionDesktop,&QAction::triggered,dock,&QWidget::hide);
}
}
